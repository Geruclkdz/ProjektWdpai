create view users_details_view
            (user_id, username, email, role, details_id, name, surname, age, profile_picture, description) as
SELECT u.id  AS user_id,
       u.username,
       u.email,
       u.role,
       ud.id AS details_id,
       ud.name,
       ud.surname,
       ud.age,
       ud.profile_picture,
       ud.description
FROM users u
         JOIN users_details ud ON u.id_user_details = ud.id;

alter table users_details_view
    owner to docker;

