create function insert_into_users_details() returns trigger
    language plpgsql
as
$$
DECLARE
    new_users_details_id INTEGER;
BEGIN
    INSERT INTO users_details (name, surname, age, profile_picture, description)
    VALUES (NULL, NULL, NULL, NULL, NULL)
    RETURNING id INTO new_users_details_id;

    -- Check if the foreign key is not NULL before updating
    IF NEW.id_user_details IS NULL THEN
        UPDATE users SET id_user_details = new_users_details_id WHERE id = NEW.id;
    END IF;

    RETURN NEW;
END;
$$;

alter function insert_into_users_details() owner to docker;

