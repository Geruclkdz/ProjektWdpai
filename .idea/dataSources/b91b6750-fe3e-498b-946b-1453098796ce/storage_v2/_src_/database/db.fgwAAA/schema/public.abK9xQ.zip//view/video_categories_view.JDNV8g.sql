create view video_categories_view (video_id, user_id, video_title, video_path, category_id, category_name) as
SELECT v.id      AS video_id,
       v.id_user AS user_id,
       v.title   AS video_title,
       v.video   AS video_path,
       c.id      AS category_id,
       c.name    AS category_name
FROM videos v
         JOIN videos_categories vc ON v.id = vc.id_videos
         JOIN categories c ON vc.id_categories = c.id;

alter table video_categories_view
    owner to docker;

